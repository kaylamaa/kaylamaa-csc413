/*************************************************
 File: CustomerDAOConcrete.java
 By: Kayla Maa
 Date: 03/23/2024
 Compile:
 Description: Creating the Concrete class
 *************************************************/
package cs413swingdemo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import javax.swing.JOptionPane;

/**
 *
 * @author karunmehta
 */
class CustomerDAOConcrete implements CustomerDAO {

    static Connection connection = null;
    PreparedStatement pStatement;
    ResultSet result;

    CustomerDAOConcrete() {

        try {

            connection = CustomerDataConnection.getDBConnection();

        } catch (SQLException se) {
            System.out.println(se.getMessage());
        }

    }

    // Method to ensure a single connection instance is used
    public static Connection getConnection() {

        if(connection == null) {
            try {

                connection = CustomerDataConnection.getDBConnection();

            } catch (SQLException se) {
                System.out.println(se.getMessage());
            }
        }

        return connection;
    }


    // Method to disconnect from the database
    public static void disconnect() throws SQLException {
        if (connection != null && !connection.isClosed()) {
            connection.close();
        }
    }



    // Method to retrieve a user from the database by ID
    @Override
    public Customer get(int anID) throws SQLException {

        pStatement = connection.prepareStatement(CustomerDataConnection.getSelect());
        pStatement.setInt(1,anID);
        result = pStatement.executeQuery();

        Customer updatedEmp = null;
        if (result.next()) {
            Customer e = new Customer();
            updatedEmp = new Customer( result.getInt("id"), result.getString("username"), result.getString("email"), result.getString("phone")
            , result.getString("sex").charAt(0), result.getString("birthday"));
        }

        return updatedEmp;
    }

    // Method to update a user in the database
    @Override
    public int update(Customer emp) throws SQLException {

        int result = -1;

        pStatement = connection.prepareStatement(CustomerDataConnection.getUpdate());
        pStatement.setString(1, emp.getUsername());
        pStatement.setString(2, emp.getEmail());
        pStatement.setString(3, emp.getPhone());
        pStatement.setInt(4, emp.getID());
        result = pStatement.executeUpdate();

        return result;
    }

    // Method to delete a user from the database
    @Override
    public int delete(Customer emp) throws SQLException {

        int res = -1;

        pStatement = connection.prepareStatement(CustomerDataConnection.getDelete());
        pStatement.setInt(1,emp.getID());
        res = pStatement.executeUpdate();

        return res;
    }

     //Method to insert a user into the database
    @Override
    public int insert(Customer emp) throws SQLException {

        int res = -1;
        pStatement = connection.prepareStatement(CustomerDataConnection.getInsert());
        pStatement.setString(1, emp.getUsername());
        pStatement.setString(2, emp.getEmail());
        res = pStatement.executeUpdate();
        disconnect();

        return res;
    }

    // Method to update a user in the database
    @Override
    public int save(Customer emp) throws SQLException {

        int res = -1;

        String nameStr = emp.getUsername();
        String[] strArr = nameStr.split(" ");
        pStatement = connection.prepareStatement(CustomerDataConnection.getInsert());
        pStatement.setString(1, strArr[0]);
        pStatement.setString(2, strArr[1]);
        pStatement.setString(3, emp.getEmail());
        pStatement.setString(4, emp.getPhone());
        pStatement.setString(5, emp.getDepartment());
        res = pStatement.executeUpdate();

        return res;
    }
    // Validates user login credentials
    public HashMap validateLogin(String id) {

        HashMap hm = null;

        try {

            pStatement = connection.prepareStatement(CustomerDataConnection.getAdmin());
            pStatement.setString(1, id);
            result = pStatement.executeQuery();

            if (result.next()) {
                hm = new HashMap();
                hm.put("ID", result.getString("userid"));
                hm.put("PWD", result.getString("pwd"));
            }

        } catch( Exception e) {
            JOptionPane.showMessageDialog(null,e.getMessage() + " Try again..");
        }

        return hm;
    }

}