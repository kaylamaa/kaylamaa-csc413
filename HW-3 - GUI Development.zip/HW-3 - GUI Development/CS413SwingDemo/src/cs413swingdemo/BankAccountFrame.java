/*************************************************
 File: BankAccountFrame.java
 By: Kayla Maa
 Date: 03/23/2024
 Compile:
 Description: Has user input activity in their BA
 and is added to the table in the database
 *************************************************/
package cs413swingdemo;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;

public class BankAccountFrame extends JFrame {
    // Declaring text fields for bank account information input
    private JTextField txtAcctNum, txtCustNum, txtBalance, txtCreateDate, txtLastUpdateDate, txtType, txtOdLimit, txtIntRate;
    private JButton btnSave;

    public BankAccountFrame() {
        setTitle("Add Bank Account");
        setLayout(new FlowLayout());
        setSize(350, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        txtAcctNum = new JTextField(20);
        txtCustNum = new JTextField(20);
        txtBalance = new JTextField(20);
        txtCreateDate = new JTextField(20);
        txtLastUpdateDate = new JTextField(20);
        txtType = new JTextField(20);
        txtOdLimit = new JTextField(20);
        txtIntRate = new JTextField(20);
        btnSave = new JButton("Save Account");

        // Adding components to the frame, with labels for each text field
        add(new JLabel("Account Number:"));
        add(txtAcctNum);
        add(new JLabel("Customer Number:"));
        add(txtCustNum);
        add(new JLabel("Balance:"));
        add(txtBalance);
        add(new JLabel("Create Date (YYYY-MM-DD):"));
        add(txtCreateDate);
        add(new JLabel("Last Update Date (YYYY-MM-DD):"));
        add(txtLastUpdateDate);
        add(new JLabel("Type:"));
        add(txtType);
        add(new JLabel("Overdraft Limit:"));
        add(txtOdLimit);
        add(new JLabel("Interest Rate:"));
        add(txtIntRate);
        add(btnSave);

        btnSave.addActionListener(this::saveBankAccount);

        setVisible(true);
    }

    // Saving bank account details entered by the user into the database
    private void saveBankAccount(ActionEvent evt) {
        try {
            int acctNum = Integer.parseInt(txtAcctNum.getText());
            int custNum = Integer.parseInt(txtCustNum.getText());
            double balance = Double.parseDouble(txtBalance.getText());
            String createDate = txtCreateDate.getText();
            String lastUpdateDate = txtLastUpdateDate.getText();
            String type = txtType.getText();
            double odLimit = Double.parseDouble(txtOdLimit.getText());
            double intRate = Double.parseDouble(txtIntRate.getText());

            insertIntoDatabase(acctNum, custNum, balance, createDate, lastUpdateDate, type, odLimit, intRate);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error saving bank account: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    // Method to insert the bank account details into the database
    private void insertIntoDatabase(int acctNum, int custNum, double balance, String createDate, String lastUpdateDate, String type, double odLimit, double intRate) {
        String url = "jdbc:mysql://localhost:3306/CS413";
        String user = "root";
        String password = "0310";
        String sql = BankAccountDataConnection.getInsert();

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, acctNum);
            pstmt.setInt(2, custNum);
            pstmt.setDouble(3, balance);
            pstmt.setString(4, createDate);
            pstmt.setString(5, lastUpdateDate);
            pstmt.setString(6, type);
            pstmt.setDouble(7, odLimit);
            pstmt.setDouble(8, intRate);
            pstmt.executeUpdate();

            JOptionPane.showMessageDialog(this, "Bank account saved successfully!");
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error saving bank account: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(BankAccountFrame::new);
    }
}
