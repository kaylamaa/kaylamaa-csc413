package cs413swingdemo;

import java.sql.*;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author karunmehta
 */
public interface CustomerDAO extends DAOInterface<Customer> {


    // Method to insert a user into the database
    //int insert(Customer emp) throws SQLException;
}

