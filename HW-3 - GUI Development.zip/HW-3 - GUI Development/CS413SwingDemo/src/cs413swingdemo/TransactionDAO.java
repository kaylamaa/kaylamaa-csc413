package cs413swingdemo;
public interface TransactionDAO extends DAOInterface<Transaction> {
    // Since DAOInterface already includes the necessary CRUD operations,
    // additional transaction-specific methods can be added here if needed.
}
