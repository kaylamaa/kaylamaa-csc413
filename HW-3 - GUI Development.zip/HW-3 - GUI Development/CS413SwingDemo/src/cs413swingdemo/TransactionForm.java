/*************************************************
 File: TransactionForm.java
 By: Kayla Maa
 Date: 03/23/2024
 Compile: Run
 Description: Creating the Transaction Form
 *************************************************/
package cs413swingdemo;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.text.SimpleDateFormat;

public class TransactionForm extends JFrame {
    private JTextField txtDateAndTime, txtTranType, txtAmount, txtDescription, txtRefID, txtAcctId;
    private JButton btnSave;

    public TransactionForm() {
        setTitle("Add Transaction");
        setLayout(new FlowLayout());
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        txtDateAndTime = new JTextField(20);
        txtTranType = new JTextField(20);
        txtAmount = new JTextField(20);
        txtDescription = new JTextField(20);
        txtRefID = new JTextField(20);
        txtAcctId = new JTextField(20);
        btnSave = new JButton("Save Transaction");

        add(new JLabel("Date and Time (dd-MM-yyyy):"));
        add(txtDateAndTime);
        add(new JLabel("Transaction Type:"));
        add(txtTranType);
        add(new JLabel("Amount:"));
        add(txtAmount);
        add(new JLabel("Description:"));
        add(txtDescription);
        add(new JLabel("Reference ID:"));
        add(txtRefID);
        add(new JLabel("Account ID:"));
        add(txtAcctId);
        add(btnSave);

        btnSave.addActionListener(this::saveTransaction);

        setVisible(true);
    }

    private void saveTransaction(ActionEvent evt) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        try {
            java.util.Date dateAndTime = dateFormat.parse(txtDateAndTime.getText());
            String tranType = txtTranType.getText();
            double amount = Double.parseDouble(txtAmount.getText());
            String description = txtDescription.getText();
            int refID = Integer.parseInt(txtRefID.getText());
            int acctId = Integer.parseInt(txtAcctId.getText());

            Transaction transaction = new Transaction(refID, acctId, amount, tranType, description, dateAndTime);
            int result = TransactionDTO.performCreate(transaction);
            if (result != -1) {
                JOptionPane.showMessageDialog(this, "Transaction saved successfully!");
            } else {
                JOptionPane.showMessageDialog(this, "Failed to save transaction.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error saving transaction: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(TransactionForm::new);
    }
}
