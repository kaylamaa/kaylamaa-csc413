/*************************************************
 File: BankAccountDataConnection.java
 By: Kayla Maa
 Date: 03/23/2024
 Compile:
 Description: Creating the Data Connection class
 *************************************************/
package cs413swingdemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
// This class provides the database connection and SQL operations for bank accounts
public class BankAccountDataConnection {

    // JDBC URL, username, and password of MySQL server
    private static final String URL = "jdbc:mysql://localhost:3306/CS413";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "0310";

    // SQL queries to be used to persist BankAccount objects as needed by the DAO
    private static final String INSERT_SQL = "INSERT INTO bank_account (acct_num, cust_num, balance, create_date, last_update_date, acct_type, od_limit, int_rate) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    private static final String SELECT_SQL_BYID = "SELECT * FROM bank_account WHERE id = ?";
    private static final String UPDATE_SQL = "UPDATE bank_account SET balance = ?, last_update_date = ? WHERE acct_num = ?";
    private static final String DELETE_SQL = "DELETE FROM bank_account WHERE acct_num = ?";

    public BankAccountDataConnection() { }

    public static Connection getDBConnection() throws SQLException {
        Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
        return connection;
    }

    public static String getInsert() {
        return INSERT_SQL;
    }

    public static String getSelect() {
        return SELECT_SQL_BYID;
    }

    public static String getUpdate() {
        return UPDATE_SQL;
    }

    public static String getDelete() {
        return DELETE_SQL;
    }

    // Additional utility methods as needed
}
