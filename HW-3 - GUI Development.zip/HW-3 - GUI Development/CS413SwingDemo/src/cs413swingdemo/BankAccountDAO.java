/*************************************************
 File: BankAccountDAO.java
 By: Kayla Maa
 Date: 03/23/2024
 Compile: Run
 Description: Creating the BankAccountDAO
 *************************************************/
package cs413swingdemo;

public interface BankAccountDAO extends DAOInterface<BankAccount> {
}
