/*************************************************
 File: CustomerForm.java
 By: Kayla Maa
 Date: 03/23/2024
 Compile: RUN
 Description: Displays the add customer form
 *************************************************/
package cs413swingdemo;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class CustomerForm extends JFrame {
    private JTextField txtFirstName, txtLastName, txtEmail;
    private JButton btnSave;

    public CustomerForm() {
        setTitle("Add Customer");
        setLayout(new FlowLayout());
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        txtFirstName = new JTextField(20);
        txtLastName = new JTextField(20);
        txtEmail = new JTextField(20);
        txtEmail = new JTextField(20);
        btnSave = new JButton("Save");

        add(new JLabel("First Name:"));
        add(txtFirstName);
        add(new JLabel("Last Name:"));
        add(txtLastName);
        add(new JLabel("Email:"));
        add(txtEmail);

        add(btnSave);

        btnSave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveCustomer();
            }
        });

        setVisible(true);
    }

    // Method to extract text from text fields and save customer
    private void saveCustomer() {
        // Implement the database insert logic here
        String firstName = txtFirstName.getText();
        String lastName = txtLastName.getText();
        String email = txtEmail.getText();

        insertIntoDatabase(firstName, lastName, email);
    }

    // Method to insert customer information into the database
    private void insertIntoDatabase(String firstName, String lastName, String email) {
        // Database connection and insert logic
        String url = "jdbc:mysql://localhost:3306/CS413";
        String user = "root";
        String password = "0310";
        String sql = "INSERT INTO customer (first_name, last_name, email) VALUES (?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, firstName);
            pstmt.setString(2, lastName);
            pstmt.setString(3, email);
            pstmt.executeUpdate();

            JOptionPane.showMessageDialog(this, "Customer saved successfully!");
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error saving customer: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        // Set look and feel to system default
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new CustomerForm();
            }
        });
    }
}

