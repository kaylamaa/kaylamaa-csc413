/*************************************************
 File: BankAccount.java
 By: Kayla Maa
 Date: 03/23/2024
 Compile:
 Description: Creating the Account class
 *************************************************/

package cs413swingdemo;

import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class BankAccount implements Comparable<BankAccount>{
    private int acctNum;
    private int custNum;
    private double balance;
    private Date createDate;
    private Date lastUpdateDate;
    private String type;
    private double odLimit;
    private double intRate;

    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");

    // Constructor
    public BankAccount(int acctNum, int custNum, double balance, String createDate, String lastUpdateDate, String type, double odLimit, double intRate) throws ParseException {
        this.acctNum = acctNum;
        this.custNum = custNum;
        this.balance = balance;
        this.createDate = dateFormat.parse(createDate);
        this.lastUpdateDate = dateFormat.parse(lastUpdateDate);
        this.type = type;
        this.odLimit = odLimit;
        this.intRate = intRate;
    }

    // Getters and setters
    public int getAcctNum() {
        return acctNum;
    }

    public void setAcctNum(int acctNum) {
        this.acctNum = acctNum;
    }

    public int getCustNum() {
        return custNum;
    }

    public void setCustNum(int custNum) {
        this.custNum = custNum;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(Date lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getOdLimit() {
        return odLimit;
    }

    public void setOdLimit(double odLimit) {
        this.odLimit = odLimit;
    }

    public double getIntRate() {
        return intRate;
    }

    public void setIntRate(double intRate) {
        this.intRate = intRate;
    }


    // Implement compareTo for PriorityQueue based on creationDate and balance
    @Override
    public int compareTo(BankAccount other) {
        // First compare by creationDate
        int dateCompare = this.createDate.compareTo(other.createDate);
        if (dateCompare != 0) {
            return dateCompare;
        }
        // If dates are the same, compare by balance (higher balance has priority)
        return Double.compare(other.balance, this.balance); // Note: For descending order
    }

    @Override
    public String toString() {
        String accountString = "BankAccount: " +
                "Account Number-" + getAcctNum() + ", " +
                "Customer Number-" + getCustNum() + ", " +
                "Balance-" + getBalance() + ", " +
                "Create Date-" + dateFormat.format(getCreateDate()) + ", " +
                "Last Update Date-" + dateFormat.format(getLastUpdateDate()) + ", " +
                "Type-" + getType() + ", " +
                "Overdraft Limit-" + getOdLimit() + ", " +
                "Interest Rate-" + getIntRate();
        return accountString;
    }

}
