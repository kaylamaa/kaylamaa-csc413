/*************************************************
 File: BankAccountSwingDemo.java
 By: Kayla Maa
 Date: 03/23/2024
 Compile:
 Description: Making sure that the correct output
 printed for BA
 *************************************************/
package cs413swingdemo;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class BankAccountSwingDemo extends JFrame {

    private JTextField acctNumField, custNumField, balanceField, createDateField, lastUpdateDateField, typeField, odLimitField, intRateField;

    public BankAccountSwingDemo() {
        setTitle("Bank Account Form");
        setSize(400, 300);
        // Exit operation
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(9, 2));

        panel.add(new JLabel("Account Number:"));
        acctNumField = new JTextField();
        panel.add(acctNumField);

        panel.add(new JLabel("Customer Number:"));
        custNumField = new JTextField();
        panel.add(custNumField);

        panel.add(new JLabel("Balance:"));
        balanceField = new JTextField();
        panel.add(balanceField);

        panel.add(new JLabel("Create Date:"));
        createDateField = new JTextField();
        panel.add(createDateField);

        panel.add(new JLabel("Last Update Date:"));
        lastUpdateDateField = new JTextField();
        panel.add(lastUpdateDateField);

        panel.add(new JLabel("Type (CH/SV):"));
        typeField = new JTextField();
        panel.add(typeField);

        panel.add(new JLabel("Overdraft Limit:"));
        odLimitField = new JTextField();
        panel.add(odLimitField);

        panel.add(new JLabel("Interest Rate:"));
        intRateField = new JTextField();
        panel.add(intRateField);

        // Submit button with an action listener to create a BankAccount object

        JButton submitButton = new JButton("Submit");
        submitButton.addActionListener((ActionEvent e) -> {
            try {
                int acctNum = Integer.parseInt(acctNumField.getText());
                int custNum = Integer.parseInt(custNumField.getText());
                double balance = Double.parseDouble(balanceField.getText());
                String createDate = createDateField.getText();
                String lastUpdateDate = lastUpdateDateField.getText();
                String type = typeField.getText();
                double odLimit = Double.parseDouble(odLimitField.getText());
                double intRate = Double.parseDouble(intRateField.getText());

                BankAccount bankAccount = new BankAccount(acctNum, custNum, balance, createDate, lastUpdateDate, type, odLimit, intRate);
                System.out.println("Bank Account Created: " + bankAccount.toString());
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Error creating bank account: " + ex.getMessage());
            }
        });
        panel.add(submitButton);

        add(panel);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new BankAccountSwingDemo());
    }
}
