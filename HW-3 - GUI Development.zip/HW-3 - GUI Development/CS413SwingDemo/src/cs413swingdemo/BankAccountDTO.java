/*************************************************
 File: BankAccountDTO.java
 By: Kayla Maa
 Date: 03/23/2024
 Compile:
 Description: Creating the DTO class
 *************************************************/
package cs413swingdemo;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.HashMap;

public class BankAccountDTO {

    private int acctNum;
    private int custNum;
    private double balance;
    private String createDate;
    private String lastUpdateDate;
    private String type;
    private double odLimit;
    private double intRate;

    static BankAccountDAOConcrete bd = new BankAccountDAOConcrete();

    public BankAccountDTO() {
        // Default constructor
    }

    public BankAccountDTO(int acctNum, int custNum, double balance, String createDate, String lastUpdateDate, String type, double odLimit, double intRate) {
        this.acctNum = acctNum;
        this.custNum = custNum;
        this.balance = balance;
        this.createDate = createDate;
        this.lastUpdateDate = lastUpdateDate;
        this.type = type;
        this.odLimit = odLimit;
        this.intRate = intRate;
    }

    // Getter and Setter methods for Bank Account
    public int getAcctNum() {
        return acctNum;
    }

    public void setAcctNum(int acctNum) {
        this.acctNum = acctNum;
    }

    public int getCustNum() {
        return custNum;
    }

    public void setCustNum(int custNum) {
        this.custNum = custNum;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public String getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(String lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getOdLimit() {
        return odLimit;
    }

    public void setOdLimit(double odLimit) {
        this.odLimit = odLimit;
    }

    public double getIntRate() {
        return intRate;
    }

    public void setIntRate(double intRate) {
        this.intRate = intRate;
    }

    // Static method to retrieve a bank account from the database by account number
    public static BankAccount getBankAccountByNumber(int acctNum) {
        BankAccount aBankAccount = null;

        try {
            aBankAccount = bd.get(acctNum);
        } catch(SQLException | ParseException se) {
            System.out.println(se.getMessage());
        }
        if(aBankAccount != null) System.out.println(aBankAccount.toString());

        System.out.println("\nFetched Bank Account with Account Number: " + acctNum + " Bank Account Details:\n" + aBankAccount.toString());
        return aBankAccount;
    }

    // Static method to update a bank account in the database
    public static int performUpdate(BankAccount aBankAccount) {
        int updateResult = -1;

        try {
            updateResult = bd.update(aBankAccount);
        } catch(SQLException se) {
            System.out.println(se.getMessage());
        }

        if(updateResult != -1) System.out.println("\nUpdate Successful");
        System.out.println("Bank Account Details:\n" + aBankAccount.toString());
        return updateResult;
    }


    @Override
    public String toString() {
        return "BankAccountDTO{" +
                "acctNum=" + acctNum +
                ", custNum=" + custNum +
                ", balance=" + balance +
                ", createDate='" + createDate + '\'' +
                ", lastUpdateDate='" + lastUpdateDate + '\'' +
                ", type='" + type + '\'' +
                ", odLimit=" + odLimit +
                ", intRate=" + intRate +
                '}';
    }
}
