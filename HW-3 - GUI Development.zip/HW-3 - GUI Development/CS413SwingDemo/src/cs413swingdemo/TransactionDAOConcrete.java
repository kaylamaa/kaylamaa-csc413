/*************************************************
 File: TransactionDAOConcrete.java
 By: Kayla Maa
 Date: 03/23/2024
 Compile: Run
 Description: Creating the Transaction Concrete
 *************************************************/
package cs413swingdemo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import javax.swing.JOptionPane;

class TransactionDAOConcrete implements TransactionDAO {

    static Connection connection = null;
    PreparedStatement pStatement;
    ResultSet result;

    TransactionDAOConcrete() {
        try {
            connection = TransactionDataConnection.getDBConnection();
        } catch (SQLException se) {
            System.out.println(se.getMessage());
        }
    }
    // Static variable for database connection to ensure only one connection is active
    public static Connection getConnection() {
        if(connection == null) {
            try {
                connection = TransactionDataConnection.getDBConnection();
            } catch (SQLException se) {
                System.out.println(se.getMessage());
            }
        }
        return connection;
    }

    // Disconnect from the database
    public static void disconnect() throws SQLException {
        if (connection != null && !connection.isClosed()) {
            connection.close();
        }
    }

    //Implementing the insert method from TransactionDAO interface
    @Override
    public int insert(Transaction transaction) throws SQLException {
        int res = -1;
        pStatement = connection.prepareStatement(TransactionDataConnection.getInsert());
        pStatement.setDate(1, new java.sql.Date(transaction.getDateAndTime().getTime()));
        pStatement.setString(2, transaction.getTranType());
        pStatement.setDouble(3, transaction.getAmount());
        pStatement.setString(4, transaction.getDescription());
        pStatement.setInt(5, transaction.getRefID());
        pStatement.setInt(6, transaction.getAcctId());
        res = pStatement.executeUpdate();
        disconnect();
        return res;
    }

    @Override
    public Transaction get(int refID) throws SQLException {
        pStatement = connection.prepareStatement(TransactionDataConnection.getSelect());
        pStatement.setInt(1, refID);
        result = pStatement.executeQuery();

        Transaction transaction = null;
        if (result.next()) {
            transaction = new Transaction(
                    result.getInt("refID"),
                    result.getInt("acct_id"),
                    result.getDouble("amount"),
                    result.getString("tran_type"),
                    result.getString("description"),
                    result.getDate("dateandtime")
            );
        }
        return transaction;
    }

    @Override
    public int update(Transaction transaction) throws SQLException {
        int res = -1;
        pStatement = connection.prepareStatement(TransactionDataConnection.getUpdate());
        pStatement.setDate(1, new java.sql.Date(transaction.getDateAndTime().getTime()));
        pStatement.setString(2, transaction.getTranType());
        pStatement.setDouble(3, transaction.getAmount());
        pStatement.setString(4, transaction.getDescription());
        pStatement.setInt(5, transaction.getRefID());
        pStatement.setInt(6, transaction.getAcctId());
        res = pStatement.executeUpdate();
        return res;
    }

    // Implementing the delete method to remove a Transaction from the database
    @Override
    public int delete(Transaction transaction) throws SQLException {
        int res = -1;
        pStatement = connection.prepareStatement(TransactionDataConnection.getDelete());
        pStatement.setInt(1, transaction.getRefID());
        res = pStatement.executeUpdate();
        return res;
    }

    @Override
    public int save(Transaction transaction) throws SQLException {
        int res = -1;
        return res;
    }
}

