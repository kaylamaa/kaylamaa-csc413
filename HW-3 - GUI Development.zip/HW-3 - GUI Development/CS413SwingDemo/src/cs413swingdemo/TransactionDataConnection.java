/*************************************************
 File: TransactionDataConnection.java
 By: Kayla Maa
 Date: 03/23/2024
 Compile: Run
 Description: Creating the Transaction Data Connection
 *************************************************/
package cs413swingdemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TransactionDataConnection {

    // JDBC URL, username, and password of MySQL server
    private static final String URL = "jdbc:mysql://localhost:3306/CS413";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "0310";

    // JDBC variables for opening and managing connection
    private static Connection connection;
    private static PreparedStatement preparedStatement;
    private static ResultSet resultSet;

    // SQL queries to be used to persist transaction objects as needed by the DAO
    private static final String INSERT_SQL = "INSERT INTO Transaction (dateAndTime, tranType, amount, decription, refID, acctId) VALUES (?, ?, ?, ?, ?, ?)";
    private static final String SELECT_SQL_BYID = "SELECT * FROM Transaction WHERE refID = ?";
    private static final String UPDATE_SQL = "UPDATE Transaction SET dateAndTime = ?, tranType = ?, amount = ?, decription = ?, acctId = ? WHERE refID = ?";
    private static final String DELETE_SQL = "DELETE FROM Transaction WHERE refID = ?";

    public TransactionDataConnection() {}

    public static Connection getDBConnection() throws SQLException {
        connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
        return connection;
    }

    public static String getInsert() {
        return INSERT_SQL;
    }

    public static String getSelect() {
        return SELECT_SQL_BYID;
    }

    public static String getUpdate() {
        return UPDATE_SQL;
    }

    public static String getDelete() {
        return DELETE_SQL;
    }

    public static String getURL() {
        return URL;
    }

    public static String getUsername() {
        return USERNAME;
    }

    public static String getPWD() {
        return PASSWORD;
    }
}
