/*************************************************
 File: Customer.java
 By: Kayla Maa
 Date: 03/23/2024
 Compile:
 Description: Creating the Customer class
 *************************************************/
package cs413swingdemo;

public class Customer {

    private String username;
    private String email;
    private String phone;
    private char sex;
    private String birthday;
    private String department;
    private int id;
    private String firstName;
    private String lastName;

    public Customer() {
        // Default constructor
    }

    public Customer(String username, String email) {
        this.username = username;
        this.email = email;
    }

    public Customer(int identity, String username, String email, String ph, char sex, String birthday) {
        this.username = username;
        this.email = email;
        this.phone = ph;
        this.id = identity;
        this.sex = sex;
        this.birthday = birthday;

    }

    // Using the CustomerDTO class for data transfer
    public void getCustomer(int i) {

        CustomerDTO empDTO = buildDTO(this.getID(), this.getUsername(), this.getEmail());

        this.setID(empDTO.getID());
        this.setUsername(empDTO.getUsername());
        this.setEmail(empDTO.getEmail());

    }

    // Static method to build a CustomerDTO object from given parameters
    public static CustomerDTO buildDTO(int empID, String name, String email) {

        CustomerDTO theDTO = new CustomerDTO(empID, name, email);
        return theDTO;

    }


    // Getter and Setter methods
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String dept) {
        this.department = dept;
    }

    public int getID() {
        return id;
    }

    public void setID(int idNum) {
        this.id = idNum;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String ph) {
        this.phone = ph;
    }

    public void setSex(char aChar) {
        this.sex = aChar;
    }

    public char getSex() {
        return sex;
    }

    public void setBirthday(String b) {
        this.birthday = b;
    }

    public String getBirthday() {
        return birthday;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @Override
    public String toString() {

        String empString = "Customer:" + " ID-" + this.getID() + ", " + " Name-" + this.getUsername() + ", " + "Email-" + this.getEmail() + ", " + "Phone-" + this.getPhone()
                + " Sex-" + this.getSex() + ", " + "Birthday-" + this.getBirthday();
        return empString;
    }

}
