package cs413swingdemo;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CustomerSwingDemo extends JFrame {

    private JTextField empID, empName, empPhone, empEmail, empSex, empBirthday;

    public CustomerSwingDemo() {
        setTitle("Customer Create Form");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(10, 2));

        JLabel empNameLabel = new JLabel("Customer Name:");
        empName = new JTextField();
        JLabel empEmailLabel = new JLabel("Customer Email:");
        empEmail = new JTextField();
        JLabel empPhoneLabel = new JLabel("Customer Phone:");
        empPhone = new JTextField();
        JLabel empIDLabel = new JLabel("Customer ID:");
        empID = new JTextField();
        JLabel empSexLabel = new JLabel("Customer Sex:");
        empSex = new JTextField();
        JLabel empBirthdayLabel = new JLabel("Customer Birthday:");
        empBirthday = new JTextField();

        panel.add(empIDLabel);
        panel.add(empID);
        panel.add(empNameLabel);
        panel.add(empName);
        panel.add(empEmailLabel);
        panel.add(empEmail);
        panel.add(empPhoneLabel);
        panel.add(empPhone);
        panel.add(empSexLabel);
        panel.add(empSex);
        panel.add(empBirthdayLabel);
        panel.add(empBirthday);

        JButton submitButton = new JButton("Submit");

        submitButton.addActionListener((ActionEvent e) -> {
            int id = Integer.parseInt(empID.getText());
            String name = empName.getText();
            String ph = empPhone.getText();
            String em = empEmail.getText();
            char sex = empSex.getText().charAt(0);
            String birth = empBirthday.getText();


            // Create a Customer object

            Customer aCustomer = new Customer(id, name, em, ph, sex, birth);
            System.out.println("Details of the Employee: " + aCustomer);
        });
        panel.add(submitButton);

        add(panel);
        setVisible(true);
    }

    public static void main(String[] args) {

        createDemoCustomerObjects();
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new CustomerSwingDemo();
            }
        });
    }

    // Similar to the EmployeeObject
    public static void createDemoCustomerObjects() {

        Customer emp1 = new Customer(44, "John Doe", "johndoe@sfsu.edu", "615.555.1212", 'M', "07-12-1999");
        Customer emp2 = new Customer(71,"Jane Deo", "janedoe@sfsu.edu","615.555.1212", 'F', "05-22-1987");
        Customer emp3 = new Customer(88,"Sam Doe", "johndoe@sfsu.edu", "615.555.1212", 'M', "04-22-1977");
        Customer emp4 = new Customer(22,"April Doe", "janedoe@sfsu.edu", "615.555.1212", 'F', "01-21-2001");

    }
}
