/*************************************************
 File: TransactionDTO.java
 By: Kayla Maa
 Date: 03/23/2024
 Compile: Run
 Description: Creating the Transaction DTO
 *************************************************/
package cs413swingdemo;
import java.sql.SQLException;
import java.util.Date;

public class TransactionDTO {
    private Date dateAndTime;
    private String tranType;
    private double amount;
    private String description;
    private int refID;
    private int acctId;

    static TransactionDAOConcrete td = new TransactionDAOConcrete();

    // Constructors and Getters/Setters

    public TransactionDTO(Date dateAndTime, String tranType, double amount, String description, int refID, int acctId) {
        this.dateAndTime = dateAndTime;
        this.tranType = tranType;
        this.amount = amount;
        this.description = description;
        this.refID = refID;
        this.acctId = acctId;
    }

    // Additional methods similar to Customer and Bank Account

    public static Transaction getTransactionByID(int refID) {
        Transaction aTransaction = null;
        try {
            aTransaction = td.get(refID);
        } catch (SQLException se) {
            System.out.println(se.getMessage());
        }
        if (aTransaction != null) System.out.println(aTransaction.toString());
        return aTransaction;
    }

    public static int performUpdate(Transaction aTransaction) {
        int updateResult = -1;
        try {
            updateResult = td.update(aTransaction);
        } catch (SQLException se) {
            System.out.println(se.getMessage());
        }
        if (updateResult != -1) System.out.println("\nUpdate Successful");
        return updateResult;
    }

    public static int performCreate(Transaction aTransaction) {
        int createResult = -1;
        try {
            createResult = td.save(aTransaction);
        } catch (SQLException se) {
            System.out.println(se.getMessage());
        }
        if (createResult != -1) System.out.println("\nTransaction Create Successful");
        return createResult;
    }
}
