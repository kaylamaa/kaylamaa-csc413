/*************************************************
 File: BankAccountDAOConcrete.java
 By: Kayla Maa
 Date: 03/23/2024
 Compile:
 Description: Creating the Concrete class
 *************************************************/
package cs413swingdemo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.HashMap;
import javax.swing.JOptionPane;
// Implements BankAccountDAO interface to interact with database for bank account operations
class BankAccountDAOConcrete implements BankAccountDAO {

    static Connection connection = null;
    PreparedStatement pStatement;
    ResultSet result;

    BankAccountDAOConcrete() {
        try {
            connection = BankAccountDataConnection.getDBConnection();
        } catch (SQLException se) {
            System.out.println(se.getMessage());
        }
    }

    // Static method to get the database connection
    public static Connection getConnection() {
        if (connection == null) {
            try {
                // Reusing the same logic to ensure a single connection instance
                connection = BankAccountDataConnection.getDBConnection();
            } catch (SQLException se) {
                System.out.println(se.getMessage());
            }
        }
        return connection;
    }

    // Static method to close the database connection
    public static void disconnect() throws SQLException {
        if (connection != null && !connection.isClosed()) {
            connection.close();
        }
    }

    // Implements the insert operation for BankAccount objects
    @Override
    public int insert(BankAccount account) throws SQLException {
        int res = -1;
        pStatement = connection.prepareStatement(BankAccountDataConnection.getInsert());
        // Assuming a similar SQL statement setup as seen in other DAOConcrete classes
        pStatement.setInt(1, account.getAcctNum());
        pStatement.setInt(2, account.getCustNum());
        // Further setup based on your BankAccountDataConnection class
        res = pStatement.executeUpdate();
        disconnect();
        return res;
    }

    // Retrieves a BankAccount object from the database based on account number
    @Override
    public BankAccount get(int acctNum) throws SQLException, ParseException {
        BankAccount account = null;
        pStatement = connection.prepareStatement(BankAccountDataConnection.getSelect());
        pStatement.setInt(1, acctNum);
        result = pStatement.executeQuery();
        if (result.next()) {
            // Match the retrieved fields
            account = new BankAccount(
                    result.getInt("acct_num"),
                    result.getInt("cust_num"),
                    result.getDouble("balance"),
                    result.getString("create_date"),
                    result.getString("last_update_date"),
                    result.getString("acct_type"),
                    result.getDouble("od_limit"),
                    result.getDouble("int_rate")
            );
        }
        return account;
    }

    // Updates a given BankAccount in the database
    @Override
    public int update(BankAccount account) throws SQLException {
        int res = -1;
        pStatement = connection.prepareStatement(BankAccountDataConnection.getUpdate());
        // Assuming a similar SQL statement setup as seen in other DAOConcrete classes
        pStatement.setInt(1, account.getAcctNum()); // And so on for other parameters
        res = pStatement.executeUpdate();
        return res;
    }

    // Deletes a given BankAccount from the database
    @Override
    public int delete(BankAccount account) throws SQLException {
        int res = -1;
        pStatement = connection.prepareStatement(BankAccountDataConnection.getDelete());
        pStatement.setInt(1, account.getAcctNum());
        res = pStatement.executeUpdate();
        return res;
    }

    @Override
    public int save(BankAccount account) throws SQLException {
        // Implement based on your business logic, similar to other DAOConcrete classes
        throw new UnsupportedOperationException("Save method not implemented.");
    }
}
