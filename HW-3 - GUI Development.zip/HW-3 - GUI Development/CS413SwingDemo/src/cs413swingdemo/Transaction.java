/*************************************************
 File: Transaction.java
 By: Kayla Maa
 Date: 03/23/2024
 Compile: Run
 Description: Creating the Transaction Class
 *************************************************/
package cs413swingdemo;
import java.util.Date;

public class Transaction {

    // Implemented all variables that will be needed in
    // the table
    private int refID;
    private int acctId;
    private double amount;
    private String tranType;
    private String description;
    private Date dateAndTime;

    public Transaction() {
        // Default constructor
    }

    public Transaction(int refID, int acctId, double amount, String tranType, String description, Date dateAndTime) {
        this.refID = refID;
        this.acctId = acctId;
        this.amount = amount;
        this.tranType = tranType;
        this.description = description;
        this.dateAndTime = dateAndTime;
    }

    // Building the DTO of a Transaction object
    public static TransactionDTO buildDTO(Date dateAndTime, String tranType, double amount, String description, int refID, int acctId) {
        TransactionDTO theDTO = new TransactionDTO(dateAndTime, tranType, amount, description, refID, acctId);
        return theDTO;
    }

    // Getter and Setter methods
    public int getRefID() {
        return refID;
    }

    public void setRefID(int refID) {
        this.refID = refID;
    }

    public int getAcctId() {
        return acctId;
    }

    public void setAcctId(int acctId) {
        this.acctId = acctId;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getTranType() {
        return tranType;
    }

    public void setTranType(String tranType) {
        this.tranType = tranType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getDateAndTime() {
        return dateAndTime;
    }

    public void setDateAndTime(Date dateAndTime) {
        this.dateAndTime = dateAndTime;
    }

    @Override
    public String toString() {
        return "Transaction{" +
                "refID=" + refID +
                ", acctId=" + acctId +
                ", amount=" + amount +
                ", tranType='" + tranType + '\'' +
                ", description='" + description + '\'' +
                ", dateAndTime=" + dateAndTime +
                '}';
    }
}
