/*************************************************
 File: AccountDTO.java
 By: Kayla Maa
 Date: 05/18/2024
 Compile:
 Description: Creating the Account DTO class
 *************************************************/
package Assignment6Controller;

import Assignment6Model.BankAccount;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

public class AccountDTO {

    private int id;
    private int customerId;
    private String accountType;
    private double balance;

    static AccountDAO ad = new AccountDAO();

    // Default constructor
    public AccountDTO() {}

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public static BankAccount accountByID(int anId) {
        BankAccount anAccount = null;

        try {
            anAccount = ad.get(anId);
        } catch(SQLException se) {
            System.out.println(se.getMessage());
        }
        if(anAccount != null) System.out.println(anAccount.toString());

        System.out.println("\nFetched Account with ID: " + anId + " Account Details:\n" + anAccount.toString());
        return anAccount;
    }

    public static List<BankAccount> findAccountsByCustomerId(int customerId) {
        List<BankAccount> accounts = null;

        accounts = ad.findAccountsByCustomerId(customerId);
        return accounts;
    }

    public static int performUpdate(BankAccount anAccount) {
        int updateResult = -1;

        try {
            updateResult = ad.update(anAccount);
        } catch(SQLException se) {
            System.out.println(se.getMessage());
        }

        if(updateResult != -1) System.out.println("\nUpdate Successful");
        System.out.println("Account Details:\n" + anAccount.toString());
        return updateResult;
    }

    public static int performCreate(HashMap<String, Object> hm) {
        int createResult = -1;

        BankAccount ba = new BankAccount();
        ba.setId((Integer) hm.get("customerId"));
        ba.setType((String) hm.get("accountType"));
        ba.setBalance((Double) hm.get("balance"));

        try {
            createResult = ad.create(ba);
        } catch(SQLException se) {
            System.out.println(se.getMessage());
        }

        if(createResult != -1) System.out.println("\nAccount Create Successful");
        System.out.println("Account Details:\n" + ba.toString());
        return createResult;
    }
}

