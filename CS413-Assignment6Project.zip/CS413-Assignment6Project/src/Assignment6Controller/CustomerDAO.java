/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/*************************************************
 File: CustomerDAO.java
 By: Kayla Maa
 Date: 05/18/2024
 Compile:
 Description: Creating the DAO class
 *************************************************/
package Assignment6Controller;

import Assignment6Model.*;
import java.sql.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import javax.swing.JOptionPane;
import java.util.List;
import java.util.ArrayList;

/**
 *
 * @author karunmehta
 */

public class CustomerDAO implements DAOInterface<BankCustomer> {
    private static final String QUERY_BY_CITY = "SELECT * FROM bankcustomer WHERE city = ?";
    static Connection connection = null;
    PreparedStatement pStatement;
    ResultSet result;
    
    public CustomerDAO() {

            connection = DataConnection.getDBConnection();

    }

    public BankCustomer getCustomerByID(int id) {
        String sql = "SELECT * FROM customers WHERE id = ?";
        BankCustomer customer = null;

        try (Connection conn = DataConnection.getDBConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                customer = new BankCustomer(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("city")
                );
                // Assuming setters are correct
                customer.setFirstName(rs.getString("firstName"));
                customer.setLastName(rs.getString("lastName"));
                customer.setEmail(rs.getString("email"));
                customer.setPhone(rs.getString("phone"));
                customer.setBirthday(rs.getString("birthday"));
            }
        } catch (SQLException e) {
            System.out.println("SQL Error: " + e.getMessage());
        }
        return customer;
    }


    public static List<BankCustomer> findCustomersByCity(String city) {
        List<BankCustomer> customers = new ArrayList<>();
        try (Connection connection = CustomerDataConnection.getDBConnection();
             PreparedStatement statement = connection.prepareStatement(QUERY_BY_CITY)) {
            statement.setString(1, city);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                CustomerAddress customerAddress = new CustomerAddress(
                        resultSet.getString("city")
                );
                BankCustomer customer = new BankCustomer(
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        customerAddress
                );
                customers.add(customer);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return customers;
    }
       
    
    // Method to disconnect from the database
    public static void disconnect() throws SQLException {
        if (connection != null && !connection.isClosed()) {
            connection.close();
        }
    }

    // Method to insert a user into the database
    @Override
    public int create(BankCustomer cust) throws SQLException {
        
        int res = -1;
        pStatement = connection.prepareStatement(CustomerDataConnection.getInsert());
        pStatement.setString(1, cust.getFirstName());
        pStatement.setString(2, cust.getLastName());
        pStatement.setString(3, cust.getEmail());
        pStatement.setString(4, cust.getPhone());
        pStatement.setString(5, cust.getBirthday());
        res = pStatement.executeUpdate();
        disconnect();
        
        return res;
    }

    // Method to retrieve a user from the database by ID
    @Override
    public BankCustomer get(int anID) throws SQLException {

        pStatement = connection.prepareStatement(CustomerDataConnection.getSelect());
        pStatement.setInt(1,anID);
        result = pStatement.executeQuery();
        
        BankCustomer updatedCust = null;
        if (result.next()) {
            updatedCust = new BankCustomer( result.getInt("id"), result.getString("first_name"), result.getString("last_name"));
            updatedCust.setEmail(result.getString("email"));
            updatedCust.setEmail(result.getString("phone"));
        }


        
        return updatedCust;
    }

    // Method to update a user in the database
    @Override
    public int update(BankCustomer cust) throws SQLException {
        
        int result = -1;
        
        pStatement = connection.prepareStatement(CustomerDataConnection.getUpdate());
        pStatement.setString(1, cust.getFirstName());
        pStatement.setString(1, cust.getLastName());

        pStatement.setString(2, cust.getEmail());
        pStatement.setString(3, cust.getPhone());
        pStatement.setInt(4, cust.getCustomerNumber());
        result = pStatement.executeUpdate();
        
        return result;
    }

    // Method to delete a user from the database
    @Override
    public int delete(BankCustomer cust) throws SQLException {
        
        int res = -1;
        
        pStatement = connection.prepareStatement(CustomerDataConnection.getDelete());
        pStatement.setInt(1, cust.getCustomerNumber());
        res = pStatement.executeUpdate();
        
        return res;
    }
    
    public HashMap validateLogin(String id) {
        
        HashMap hm = null;
        
        try {
            
            pStatement = connection.prepareStatement(CustomerDataConnection.getAdmin());
            pStatement.setString(1, id);
            result = pStatement.executeQuery();
            
            if (result.next()) {
                hm = new HashMap();
                hm.put("ID", result.getString("userid"));
                hm.put("PWD", result.getString("pwd"));
            }
            
        } catch( Exception e) {
            JOptionPane.showMessageDialog(null,e.getMessage() + " Try again..");
        }
        
        return hm;
    }
    
}
