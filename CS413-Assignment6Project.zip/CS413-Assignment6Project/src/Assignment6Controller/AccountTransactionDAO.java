/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/*************************************************
 File: AccountTransactionDAO.java
 By: Kayla Maa
 Date: 05/18/2024
 Compile:
 Description: Creating the DAO class
 *************************************************/
package Assignment6Controller;

import Assignment6Model.*;
import Assignment6Model.BankCustomer;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import javax.swing.JOptionPane;
import java.util.HashMap;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author karunmehta
 */

public class AccountTransactionDAO implements DAOInterface<BankAccountTransaction> {

    static Connection connection = null;
    PreparedStatement pStatement;
    ResultSet result;
    
    AccountTransactionDAO() {

            connection = DataConnection.getDBConnection();      

    }
       
    
    // Method to disconnect from the database
    public static void disconnect() throws SQLException {
        if (connection != null && !connection.isClosed()) {
            connection.close();
        }
    }

    // Method to find transactions by account ID
    public static List<BankAccountTransaction> findTransactionsByAccountId(int accountId) {
        List<BankAccountTransaction> transactions = new ArrayList<>();
        String query = "SELECT * FROM accounttransaction WHERE sourceAccount = ? OR destinationAccount = ?";

        try (Connection conn = DataConnection.getDBConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, accountId);
            stmt.setInt(2, accountId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                BankAccount sourceAccount = new BankAccount();
                sourceAccount.setId(rs.getInt("sourceAccount"));

                BankAccount destinationAccount = new BankAccount();
                destinationAccount.setId(rs.getInt("destinationAccount"));

                BankAccountTransaction transaction = new BankAccountTransaction(
                        rs.getInt("id"),
                        rs.getTimestamp("createDate"),
                        rs.getDouble("amount"),
                        rs.getString("description"),
                        rs.getString("status"),
                        sourceAccount,
                        destinationAccount,
                        rs.getString("type")
                );
                transactions.add(transaction);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return transactions;
    }


    // Method to insert a user into the database
    @Override
    public int create(BankAccountTransaction at) throws SQLException {
        
        int res = -1;
        pStatement = connection.prepareStatement(TransactionDataConnection.getInsert());
        pStatement.setTimestamp(1, at.getCreateDate());
        pStatement.setString(2, at.getType());
        pStatement.setDouble(3, at.getAmount());
        pStatement.setString(4, at.getDescription());
        pStatement.setInt(5, at.id());
      
        res = pStatement.executeUpdate();
        disconnect();
        
        return res;
    }

    // Method to retrieve a uscustomeraddress from the database by ID
    @Override
    public BankAccountTransaction get(int acctID) throws SQLException {

        pStatement = connection.prepareStatement(AccountDataConnection.getSelect());
        pStatement.setInt(1,acctID);
        result = pStatement.executeQuery();
        
        BankAccountTransaction at = null;
        if (result.next()) {
            at = new BankAccountTransaction();
            at.setCreateDate(result.getTimestamp("create_date"));
            at.setType(result.getString("tran_type"));
            at.setAmount(result.getDouble("amount"));
            at.setDescription(result.getString("summary"));
            at.setID(result.getInt("acct_id"));
        }

        return at;
    }

    // Method to save a transaction
    public static void saveTransaction(BankAccountTransaction transaction) {
        String query = "INSERT INTO transaction (createDate, amount, description, status, sourceAccount, destinationAccount, type) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DataConnection.getDBConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setTimestamp(1, transaction.getCreateDate());
            stmt.setDouble(2, transaction.getAmount());
            stmt.setString(3, transaction.getDescription());
            stmt.setString(4, transaction.getStatus());
            stmt.setInt(5, transaction.getSourceAccount().getId());
            stmt.setInt(6, transaction.getDestinationAccount().getId());
            stmt.setString(7, transaction.getType());

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Updating transaction not allowed
    @Override
    public int update(BankAccountTransaction t) throws SQLException {
        
        System.out.println("Once created, cannot update transaction for an account");
        
        return -1;
    }

    // Deleting transaction not allowed
    @Override
    public int delete(BankAccountTransaction t) throws SQLException {
        
        System.out.println("Once created, cannot delete transaction for an account");
        
        return -1;
    }
    
}

