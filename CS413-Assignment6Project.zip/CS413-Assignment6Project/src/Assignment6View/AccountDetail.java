/*************************************************
 File: AccountDetail.java
 By: Kayla Maa
 Date: 05/18/2024
 Compile:
 Description: Account Detail showing info for Acc
 *************************************************/
package Assignment6View;

import Assignment6Model.BankAccount;
import Assignment6Controller.AccountDAO;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AccountDetail extends javax.swing.JFrame {

    private BankAccount account;
    private JTextField accountTypeField;
    private JTextField balanceField;
    private JButton saveButton;
    private JButton cancelButton;

    // Constructor to initialize with BankAccount
    public AccountDetail(BankAccount account) {
        this.account = account;
        initComponentsCustom();
        populateAccountDetails();
    }

    // Custom initialization method to avoid conflicts
    @SuppressWarnings("unchecked")
    private void initComponentsCustom() {
        setTitle("Account Detail");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null);

        JLabel jLabel1 = new JLabel("Account Detail");
        jLabel1.setFont(new java.awt.Font("Helvetica Neue", 1, 14));
        jLabel1.setBounds(150, 10, 100, 25);
        getContentPane().add(jLabel1);

        JLabel jLabel2 = new JLabel("Account Type:");
        jLabel2.setBounds(30, 50, 100, 25);
        getContentPane().add(jLabel2);

        accountTypeField = new JTextField();
        accountTypeField.setBounds(140, 50, 200, 25);
        getContentPane().add(accountTypeField);

        JLabel jLabel3 = new JLabel("Balance:");
        jLabel3.setBounds(30, 90, 100, 25);
        getContentPane().add(jLabel3);

        balanceField = new JTextField();
        balanceField.setBounds(140, 90, 200, 25);
        getContentPane().add(balanceField);

        saveButton = new JButton("Save");
        saveButton.setBounds(140, 130, 80, 25);
        getContentPane().add(saveButton);

        cancelButton = new JButton("Cancel");
        cancelButton.setBounds(230, 130, 80, 25);
        getContentPane().add(cancelButton);

        saveButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                saveAccount();
            }
        });

        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                cancelActionPerformed(evt);
            }
        });
    }

    private void populateAccountDetails() {
        accountTypeField.setText(account.getType());
        balanceField.setText(String.valueOf(account.getBalance()));
    }

    private void saveAccount() {
        account.setType(accountTypeField.getText());
        account.setBalance(Double.parseDouble(balanceField.getText()));
        JOptionPane.showMessageDialog(this, "Account Detail Updated Successfully.");
        this.setVisible(false);
    }

    private void cancelActionPerformed(ActionEvent evt) {
        this.setVisible(false);
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                BankAccount sampleAccount = new BankAccount(1, 1, "Checking", 1000.0); // Create a sample account
                new AccountDetail(sampleAccount).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    // End of variables declaration//GEN-END:variables
}
